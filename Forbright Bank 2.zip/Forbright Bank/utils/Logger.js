const log = (level, message, data = {}) => {
    console.log(JSON.stringify({ level, message, ...data, timestamp: new Date().toISOString() }));
  };
  
  module.exports = {
    info: (msg, data) => log("INFO", msg, data),
    error: (msg, data) => log("ERROR", msg, data),
  };
  