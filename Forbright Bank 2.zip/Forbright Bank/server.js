require("dotenv").config();
const express = require("express");
const fetch = require("node-fetch"); // npm install node-fetch
const { forwardToS3 } = require("./services/forwardService");
const logger = require("./utils/Logger");

const app = express();
const PORT = 3000;

app.use(express.json());

let customers = [];

// ----------------- Helper: Map Random User to Customer -----------------
const mapRandomUserToCustomer = (randomUser) => {
  const originalDate = new Date(randomUser.registered.date);
  const month = String(originalDate.getMonth() + 1).padStart(2, "0");
  const day = String(originalDate.getDate()).padStart(2, "0");
  const created_at = `2025-${month}-${day}`; // force 2025 for testing

  return {
    id: customers.length + 1,
    first_name: randomUser.name.first,
    last_name: randomUser.name.last,
    email: randomUser.email,
    created_at,
  };
};

// ----------------- Load Random Users on Server Start -----------------
async function loadRandomUsers() {
  try {
    const response = await fetch(
      "https://randomuser.me/api/?results=100&inc=name,email,registered"
    );
    const data = await response.json();
    customers = data.results.map(mapRandomUserToCustomer);
    logger.info("Random users loaded:", customers);
    // ✅ Optional: Upload the random users list to S3
    
    await forwardToS3(customers);

    logger.info("✅ Random users uploaded to S3 successfully");

  } catch (err) {
    logger.error("Failed to fetch random users:", { error: err.stack || err.message || err });
  }
}

loadRandomUsers();

// ----------------- POST /onboarding -----------------
app.post("/onboarding", async (req, res) => {
  const { firstName, lastName, email } = req.body;

  logger.info("Received onboarding event", { firstName, lastName, email });

  if (!firstName || !lastName || !email) {
    logger.error("Missing required fields", { body: req.body });
    return res
      .status(400)
      .json({ error: "Missing required fields: firstName, lastName, email" });
  }

  try {
    await forwardToS3({ firstName, lastName, email });

    customers.push({
      id: customers.length + 1,
      first_name: firstName,
      last_name: lastName,
      email,
      created_at: new Date().toISOString().slice(0, 10),
    });

    logger.info("Successfully forwarded and stored data", {
      firstName,
      lastName,
      email,
    });
    res.status(200).json({ message: "Data forwarded and stored successfully" });
  } catch (err) {
    logger.error("Failed to forward data", { error: err.message });
    res.status(500).json({ error: "Failed to forward data" });
  }
});

app.post("/query", async (req, res) => {
    const { queryType } = req.body;
    if (!queryType)
      return res.status(400).json({ error: "queryType is required" });
  
    const customerArray = Array.isArray(customers)
      ? customers
      : Object.values(customers);
  
    let result;
  
    switch (queryType) {
      case "recent10":
        result = customerArray
          .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
          .slice(0, 10);
        break;
  
      case "gmail":
        result = customerArray.filter((c) => c.email.endsWith("@example.com"));
        break;
  
      case "countPerMonth2025":
        result = customerArray
          .filter((c) => new Date(c.created_at).getFullYear() === 2025)
          .reduce((acc, c) => {
            const month = c.created_at.slice(0, 7);
            acc[month] = (acc[month] || 0) + 1;
            return acc;
          }, {});
        break;
  
      case "duplicateEmails":
        const counts = {};
        customerArray.forEach((c) => {
          if (c.email) counts[c.email] = (counts[c.email] || 0) + 1;
        });
  
        result = Object.entries(counts)
          .filter(([email, count]) => count > 1)
          .map(([email, count]) => ({ email, occurrences: count }));
        break;
  
      case "firstNameA":
        result = customerArray.filter((c) => c.first_name.startsWith("A"));
        break;
  
      default:
        return res.status(400).json({ error: "Unknown queryType" });
    }
  
    logger.info("Query executed", { queryType, result });
    
    // Send the response first
    res.json({ queryType, result });
  
    // Then forward the result to S3 asynchronously, no need to block response
    try {
      await forwardToS3({ queryType, result });
      logger.info("Query result forwarded to S3");
    } catch (err) {
      logger.error("Failed to forward query result to S3", { error: err.message });
    }
  });
  
// ----------------- Start server -----------------
app.listen(PORT, () => {
  logger.info("Server started", { port: PORT });
});
