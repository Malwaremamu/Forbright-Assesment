require("dotenv").config();
const express = require("express");
const axios = require("axios");
const axiosRetry = require("axios-retry").default;
const { forwardToS3 } = require("./services/forwardService");
const logger = require("./utils/Logger");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

let customers = [];

// -------------------- AXIOS CONFIGURATION --------------------
const apiClient = axios.create({ timeout: 5000 }); // 5s timeout
axiosRetry(apiClient, {
  retries: 3,
  retryDelay: (retryCount) => retryCount * 1000, // exponential-ish backoff
  retryCondition: (error) =>
    error.code === "ECONNABORTED" || !error.response || error.response.status >= 500,
});

// -------------------- MAP RANDOM USER TO CUSTOMER --------------------
const mapRandomUserToCustomer = (randomUser) => {
  const originalDate = new Date(randomUser.registered.date);
  const month = String(originalDate.getMonth() + 1).padStart(2, "0");
  const day = String(originalDate.getDate()).padStart(2, "0");
  const created_at = `2025-${month}-${day}`; // force 2025 for demo

  return {
    id: customers.length + 1,
    first_name: randomUser.name.first,
    last_name: randomUser.name.last,
    email: randomUser.email,
    created_at,
  };
};

// -------------------- LOAD RANDOM USERS ON START --------------------
async function loadRandomUsers() {
  try {
    logger.info("Fetching random users...");

    const { data } = await apiClient.get(
      "https://randomuser.me/api/?results=100&inc=name,email,registered"
    );

    customers = data.results.map(mapRandomUserToCustomer);
    logger.info("✅ Random users loaded successfully", { count: customers.length });

    // Upload all customers in one bulk file (correct way)
    await forwardToS3(customers, { bulk: true });
    
    logger.info("✅ Random users uploaded to S3 successfully");
  } catch (err) {
    logger.error("❌ Failed to fetch or upload random users", {
      message: err.message,
      stack: err.stack,
    });
  }
}

loadRandomUsers();

// -------------------- POST /onboarding --------------------
app.post("/onboarding", async (req, res) => {
  const { firstName, lastName, email } = req.body;

  if (!firstName || !lastName || !email) {
    logger.error("Missing required fields", { body: req.body });
    return res
      .status(400)
      .json({ error: "Missing required fields: firstName, lastName, email" });
  }

  logger.info("Received onboarding event", { firstName, lastName, email });

  try {
    await forwardToS3({ firstName, lastName, email }, { bulk: false });

    customers.push({
      id: customers.length + 1,
      first_name: firstName,
      last_name: lastName,
      email,
      created_at: new Date().toISOString().slice(0, 10),
    });

    logger.info("✅ Onboarding data forwarded & stored", { firstName, lastName, email });
    res.status(200).json({ message: "Data forwarded and stored successfully" });
  } catch (err) {
    logger.error("❌ Failed to forward onboarding data", { error: err.message });
    res.status(500).json({ error: "Failed to forward data" });
  }
});

// -------------------- POST /query --------------------
app.post("/query", async (req, res) => {
  const { queryType } = req.body;

  if (!queryType)
    return res.status(400).json({ error: "queryType is required" });

  const customerArray = Array.isArray(customers)
    ? customers
    : Object.values(customers);

  let result;

  try {
    switch (queryType) {
      case "recent10":
        result = customerArray
          .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
          .slice(0, 10);
        break;

      case "gmail":
        result = customerArray.filter((c) => c.email.endsWith("@example.com"));
        break;

      case "countPerMonth2025":
        result = customerArray
          .filter((c) => new Date(c.created_at).getFullYear() === 2025)
          .reduce((acc, c) => {
            const month = c.created_at.slice(0, 7);
            acc[month] = (acc[month] || 0) + 1;
            return acc;
          }, {});
        break;

      case "duplicateEmails":
        const counts = {};
        customerArray.forEach((c) => {
          if (c.email) counts[c.email] = (counts[c.email] || 0) + 1;
        });
        result = Object.entries(counts)
          .filter(([email, count]) => count > 1)
          .map(([email, count]) => ({ email, occurrences: count }));
        break;

      case "firstNameA":
        result = customerArray.filter((c) => c.first_name.startsWith("A"));
        break;

      default:
        return res.status(400).json({ error: "Unknown queryType" });
    }

    // Send the response immediately
    res.json({ queryType, result });

    // Forward to S3 in background
    forwardToS3({ queryType, result }, { bulk: false })
      .then(() => logger.info("✅ Query result forwarded to S3", { queryType }))
      .catch((err) =>
        logger.error("❌ Failed to forward query result to S3", {
          queryType,
          error: err.message,
        })
      );
  } catch (err) {
    logger.error("❌ Query execution failed", { queryType, error: err.message });
    res.status(500).json({ error: "Query execution failed" });
  }
});

// -------------------- START SERVER --------------------
app.listen(PORT, () => {
  logger.info("🚀 Server started", { port: PORT });
});
