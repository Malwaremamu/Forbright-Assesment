const express = require("express");
const { forwardToS3 } = require("./services/forwardService");
const logger = require("./utils/Logger");

const app = express();
const PORT = 3000;

app.use(express.json());

app.post("/onboarding", async (req, res) => {
  const { firstName, lastName, email } = req.body;

  logger.info("Received onboarding event", { firstName, lastName, email });

  // Basic validation
  if (!firstName || !lastName || !email) {
    logger.error("Missing required fields", { body: req.body });
    return res.status(400).json({ error: "Missing required fields" });
  }

  try {
    await forwardToS3({ firstName, lastName, email });
    res.status(200).json({ message: "Data forwarded successfully" });
  } catch (err) {
    res.status(500).json({ error: "Failed to forward data" });
  }
});

app.listen(PORT, () => {
  logger.info("Server started", { port: PORT, endpoint: "/onboarding" });
});
